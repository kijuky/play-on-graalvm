/*
 * Copyright (C) Lightbend Inc. <https://www.lightbend.com>
 */

package com.typesafe.play.docs.sbtplugin

import sbt._
import sbt.io.Path._

private[sbtplugin] class PlayDocsValidationCompat {
  def getMarkdownFiles(base: java.io.File): Seq[(File, String)] = {
    (base / "manual" ** "*.md").get.pair(relativeTo(base))
  }
}
