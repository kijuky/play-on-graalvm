
package views.html.helper

import _root_.play.twirl.api.TwirlFeatureImports._
import _root_.play.twirl.api.TwirlHelperImports._
import _root_.play.twirl.api.Html
import _root_.play.twirl.api.JavaScript
import _root_.play.twirl.api.Txt
import _root_.play.twirl.api.Xml
import play.api.templates.PlayMagic._

object defaultFieldConstructor extends _root_.play.twirl.api.BaseScalaTemplate[play.twirl.api.HtmlFormat.Appendable,_root_.play.twirl.api.Format[play.twirl.api.HtmlFormat.Appendable]](play.twirl.api.HtmlFormat) with _root_.play.twirl.api.Template1[FieldElements,play.twirl.api.HtmlFormat.Appendable] {

  /**
 * Default field constructor.
 *
 * It generates field as following:
 * {{{
 * <dl class="error">
 *   <dt><label for="name">Your name:</label></dt>
 *   <dd><input type="text" id="name" name="name"></dd>
 *   <dd class="error">This field is required</dd>
 *   <dd class="info">Required</dd>
 * </dl>
 * }}}
 *
 * @param el The field informations.
 */
  def apply/*16.2*/(elements: FieldElements):play.twirl.api.HtmlFormat.Appendable = {
    _display_ {
      {


Seq[Any](format.raw/*17.1*/("""<dl class=""""),_display_(/*17.13*/elements/*17.21*/.args.get(Symbol("_class"))),format.raw/*17.48*/(""" """),_display_(/*17.50*/if(elements.hasErrors)/*17.72*/ {_display_(Seq[Any](format.raw/*17.74*/("""error""")))}),format.raw/*17.80*/("""" id=""""),_display_(/*17.87*/elements/*17.95*/.args.get(Symbol("_id")).getOrElse(elements.id + "_field")),format.raw/*17.153*/("""">
    """),_display_(/*18.6*/if(elements.hasName)/*18.26*/ {_display_(Seq[Any](format.raw/*18.28*/("""
    """),format.raw/*19.5*/("""<dt>"""),_display_(/*19.10*/elements/*19.18*/.name),format.raw/*19.23*/("""</dt>
    """)))}/*20.7*/else/*20.12*/{_display_(Seq[Any](format.raw/*20.13*/("""
    """),format.raw/*21.5*/("""<dt><label for=""""),_display_(/*21.22*/elements/*21.30*/.id),format.raw/*21.33*/("""">"""),_display_(/*21.36*/elements/*21.44*/.label),format.raw/*21.50*/("""</label></dt>
    """)))}),format.raw/*22.6*/("""
    """),format.raw/*23.5*/("""<dd>"""),_display_(/*23.10*/elements/*23.18*/.input),format.raw/*23.24*/("""</dd>
    """),_display_(/*24.6*/elements/*24.14*/.errors.map/*24.25*/ { error =>_display_(Seq[Any](format.raw/*24.36*/("""
        """),format.raw/*25.9*/("""<dd class="error">"""),_display_(/*25.28*/error),format.raw/*25.33*/("""</dd>
    """)))}),format.raw/*26.6*/("""
    """),_display_(/*27.6*/elements/*27.14*/.infos.map/*27.24*/ { info =>_display_(Seq[Any](format.raw/*27.34*/("""
        """),format.raw/*28.9*/("""<dd class="info">"""),_display_(/*28.27*/info),format.raw/*28.31*/("""</dd>
    """)))}),format.raw/*29.6*/("""
"""),format.raw/*30.1*/("""</dl>
"""))
      }
    }
  }

  def render(elements:FieldElements): play.twirl.api.HtmlFormat.Appendable = apply(elements)

  def f:((FieldElements) => play.twirl.api.HtmlFormat.Appendable) = (elements) => apply(elements)

  def ref: this.type = this

}


              /*
                  -- GENERATED --
                  SOURCE: core/play/src/main/scala/views/helper/defaultFieldConstructor.scala.html
                  HASH: 429e6678ce203edf83d5fa63bd29e128797c3661
                  MATRIX: 988->357|1108->383|1147->395|1164->403|1212->430|1241->432|1272->454|1312->456|1349->462|1383->469|1400->477|1480->535|1514->543|1543->563|1583->565|1615->570|1647->575|1664->583|1690->588|1719->600|1732->605|1771->606|1803->611|1847->628|1864->636|1888->639|1918->642|1935->650|1962->656|2011->675|2043->680|2075->685|2092->693|2119->699|2156->710|2173->718|2193->729|2242->740|2278->749|2324->768|2350->773|2391->784|2423->790|2440->798|2459->808|2507->818|2543->827|2588->845|2613->849|2654->860|2682->861
                  LINES: 29->16|34->17|34->17|34->17|34->17|34->17|34->17|34->17|34->17|34->17|34->17|34->17|35->18|35->18|35->18|36->19|36->19|36->19|36->19|37->20|37->20|37->20|38->21|38->21|38->21|38->21|38->21|38->21|38->21|39->22|40->23|40->23|40->23|40->23|41->24|41->24|41->24|41->24|42->25|42->25|42->25|43->26|44->27|44->27|44->27|44->27|45->28|45->28|45->28|46->29|47->30
                  -- GENERATED --
              */
          